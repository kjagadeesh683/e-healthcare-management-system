package hospital.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import hospital.databaseconnection.DBCon;
import hospital.enail.Email;
import hospital.model.DoctorModel;
import hospital.model.FrontOfficeModel;

public class FrontOfficeDao {
	public String addFrontOffice(FrontOfficeModel fom) {

		try {
			Connection con = DBCon.getConnection();
			Statement st = con.createStatement();
			int a = st.executeUpdate(
					"insert into frontOffice(frontofficename,receptionistname,email,phone,password) values('"
							+ fom.getFrontofficename() + "','" + fom.getReceptionistname() + "','" + fom.getEmail()
							+ "','" + fom.getPhone() + "','" + fom.getPassword() + "')",Statement.RETURN_GENERATED_KEYS);
			ResultSet rs= st.getGeneratedKeys();
			if(rs.next()) {
				Email.sendEmail("Front Office Account Created", "Hello "+fom.getFrontofficename()+"  Your Front Office Account Created. your login creditials are  ID: "+rs.getInt(1)+" and password is: "+fom.getPassword(), fom.getEmail());

			}
			return "Front Office added Successfully";
		} catch (Exception e) {
			System.out.println(e);
			return "Front Office adding Failed";
		}

	}

	public List<FrontOfficeModel> viewFrontOffice() {

		try {
			Connection con = DBCon.getConnection();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from frontOffice");
			List<FrontOfficeModel> foList = new ArrayList<FrontOfficeModel>();
			while (rs.next()) {
				FrontOfficeModel fom = new FrontOfficeModel();

				fom.setFrontOfficeId(rs.getString("frontOfficeId"));
				fom.setFrontofficename(rs.getString("frontofficename"));
				fom.setReceptionistname(rs.getString("receptionistname"));
				fom.setEmail(rs.getString("email"));
				fom.setPhone(rs.getString("phone"));
				fom.setPassword(rs.getString("password"));
				fom.setStatus(rs.getString("status"));

				foList.add(fom);
			}
			return foList;

		} catch (Exception e) {
			System.out.println(e);

			return null;
		}

	}

	public Boolean frontOfficeLogin(String userId, String password, HttpServletResponse response, HttpSession session) {
		try {
			Connection con = DBCon.getConnection();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(
					"select * from frontOffice where frontOfficeId='" + userId + "' and password='" + password + "'  and status!='disabled'");
			if (rs.next()) {

				session.setAttribute("frontOfficeId", rs.getString("frontOfficeId"));
				session.setAttribute("frontofficename", rs.getString("frontofficename"));
				session.setAttribute("receptionistname", rs.getString("receptionistname"));
				session.setAttribute("role", "frontOffice");
				response.sendRedirect("frontOfficeHome.jsp");

			} else {
				response.sendRedirect("messageFailed.jsp?status=invalied crediantials");
			}

		} catch (Exception e) {
			System.out.println(e);

		}

		return false;

	}

	public FrontOfficeModel editFrontOffice(String frontOfficeId) {
		try {
			Connection con = DBCon.getConnection();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from frontOffice where frontOfficeId='" + frontOfficeId + "'");

			if (rs.next()) {
				FrontOfficeModel fom = new FrontOfficeModel();
				fom.setFrontOfficeId(rs.getString("frontOfficeId"));
				fom.setFrontofficename(rs.getString("frontofficename"));
				fom.setReceptionistname(rs.getString("receptionistname"));
				fom.setEmail(rs.getString("email"));
				fom.setPhone(rs.getString("phone"));
				fom.setPassword(rs.getString("password"));
				return fom;

			}

		} catch (Exception e) {
			System.out.println(e);

		}

		return null;

	}

	public String editParticularFrontOffice(FrontOfficeModel fom) {

		try {
			Connection con = DBCon.getConnection();
			Statement st = con.createStatement();
			int a = st.executeUpdate("update frontOffice set frontofficename='" + fom.getFrontofficename()
					+ "',receptionistname='" + fom.getReceptionistname() + "',email='" + fom.getEmail() + "',phone='"
					+ fom.getPhone() + "',password='" + fom.getPassword() + "'  where frontOfficeId='"
					+ fom.getFrontOfficeId() + "'");
			return "FrontOffice Updated Successfully";
		} catch (Exception e) {
			System.out.println(e);
			return "FrontOffice Updating Failed";
		}

	}
	public void frontOfficeStatus(String frontOfficeId,String status,HttpServletResponse response) {
		String newStatus=null;
		if(status.equalsIgnoreCase("Disabled")) {
			
			newStatus="Enabled";
		}
		else {
			
			newStatus="Disabled";
		}
		
		try {
			Connection con = DBCon.getConnection();
			Statement st = con.createStatement();
			int a = st.executeUpdate("update frontOffice set status='"+newStatus+"'   where frontOfficeId='"+frontOfficeId+"'");
			response.sendRedirect("viewFrontOffice.jsp");
		} catch (Exception e) {
			System.out.println(e);
			
		}
		
	}
}
