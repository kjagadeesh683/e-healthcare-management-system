package hospital.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import hospital.databaseconnection.DBCon;
import hospital.model.DoctorModel;

import hospital.model.PatientModel;
import hospital.model.ReadingsModel;

public class ReadingsDeo {
		public String addReadings(ReadingsModel rm) {
			try {
				Connection con = DBCon.getConnection();
				Statement st = con.createStatement();
				int a = st.executeUpdate(
						"insert into reading(readingName,readingValue,status,doctorId,patientId) values('"+rm.getReadingName()+"','"+rm.getReadingValue()+"','"+rm.getStatus()+"','"+rm.getDoctorId()+"','"+rm.getPatientId()+"')");
				return "Readings added Successfully";
			} catch (Exception e) {
				System.out.println(e);
				return "Readings adding Failed";
			}
			
			
		}
		public List<ReadingsModel> viewReadings(String patientId ){
			   
			   try {
					Connection con = DBCon.getConnection();
					Statement st = con.createStatement();
					ResultSet rs=st.executeQuery("select * from reading where patientId='"+patientId+"'");
					List<ReadingsModel> rList =new ArrayList<ReadingsModel>();
					while(rs.next()) {
						ReadingsModel rm=new ReadingsModel();
						rm.setDoctorId(rs.getString("doctorId"));
						rm.setPatientId(rs.getString("patientId"));
						rm.setReadingId(rs.getString("readingId"));
						rm.setReadingName(rs.getString("readingName"));
						rm.setReadingValue(rs.getString("readingValue"));
						rm.setStatus(rs.getString("status"));
						rm.setDatee(rs.getString("datee"));
						Statement st2 = con.createStatement();
						ResultSet rs2=st2.executeQuery("select * from patient where patientId='"+patientId+"'");
						if(rs2.next()) {
							PatientModel pm = new PatientModel();
							pm.setName(rs2.getString("name"));
							pm.setEmail(rs2.getString("email"));
							pm.setPhone(rs2.getString("phone"));
							pm.setAddress(rs2.getString("address"));
							pm.setAge(rs2.getString("age"));
							pm.setGender(rs2.getString("gender"));
							pm.setPurpose(rs2.getString("purpose"));
							pm.setPassword(rs2.getString("password"));
							
							
							rm.setPm(pm);
						}
						Statement st3 = con.createStatement();
						ResultSet rs3=st3.executeQuery("select * from doctor where doctorId='"+rm.getDoctorId()+"'");
						if(rs3.next()) {
							DoctorModel dm = new DoctorModel();
							dm.setFirstname(rs3.getString("firstname"));
							dm.setLastname(rs3.getString("lastname"));
							dm.setEmail(rs3.getString("email"));
							dm.setPhone(rs3.getString("phone"));
							dm.setPassword(rs3.getString("password"));
							dm.setDesignation(rs3.getString("designation"));
							dm.setDesignation(rs3.getString("specialization"));
							dm.setExperiance(rs3.getString("experiance"));
							dm.setDateOfJoining(rs3.getString("dateOfJoining"));
							dm.setShiftStartTime(rs3.getString("shiftStartTime"));
							dm.setShiftEndTime(rs3.getString("shiftEndTime"));
							dm.setDoctorId(rs3.getString("doctorId"));
						
							
							
							rm.setDm(dm);
						}
						rList.add(rm);
					}
					return rList;
				
				} catch (Exception e) {
					System.out.println(e);
					
					 return null;
				}
			   
			   
			  
		   }
}
