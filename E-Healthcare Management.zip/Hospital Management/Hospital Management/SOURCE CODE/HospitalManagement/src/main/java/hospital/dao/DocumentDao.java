package hospital.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import hospital.databaseconnection.DBCon;
import hospital.model.DoctorModel;
import hospital.model.DocumentsModel;
import hospital.model.LabModel;
import hospital.model.LabTestModel;
import hospital.model.PatientModel;
public class DocumentDao {
	public String uploadDocument(DocumentsModel dm) {
		try {
			Connection con = DBCon.getConnection();
			Statement st = con.createStatement();
			int a = st.executeUpdate(
					"insert into document(reportName,reportDocument,reportDescription,charge,doctorId,patientId,laboratoryId,labTestRequestId) values('"
							+ dm.getReportName() + "','" + dm.getReportDocument() + "','" + dm.getReportDescription()
							+ "','" + dm.getCharge() + "','" + dm.getDoctorId() + "','" + dm.getPatientId() + "','"
							+ dm.getLaboratoryId() + "','" + dm.getLabTestRequestId() + "')");
			return "Documents uploaded Successfully";
		} catch (Exception e) {
			System.out.println(e);
			return "Documents uploading Failed";
		}

	
	}
	public List<DocumentsModel> viewDocument(String laboratoryId,String labTestRequestId){
		   
		   try {
			   String query ="select * from document where labTestRequestId='"+labTestRequestId+"'";
			   if(laboratoryId!=null) {
				   query ="select * from document where laboratoryId='"+laboratoryId+"' and labTestRequestId='"+labTestRequestId+"'";
			   }
			   System.out.println(query);
				Connection con = DBCon.getConnection();
				Statement st = con.createStatement();
				ResultSet rs=st.executeQuery(query);
				List<DocumentsModel> dList =new ArrayList<DocumentsModel>();
				while(rs.next()) {
					DocumentsModel dcm=new DocumentsModel();
					dcm.setDoctorId(rs.getString("doctorId"));
					dcm.setPatientId(rs.getString("patientId"));
					dcm.setDatee(rs.getString("datee"));
					dcm.setDocumentId(rs.getString("documentId"));
					dcm.setReportName(rs.getString("reportName"));
					dcm.setReportDocument(rs.getString("reportDocument"));
					dcm.setReportDescription(rs.getString("reportDescription"));
					dcm.setCharge(rs.getString("charge"));
					dcm.setLaboratoryId(rs.getString("laboratoryId"));
					dcm.setLabTestRequestId(rs.getString("labTestRequestId"));
					
					Statement st2 = con.createStatement();
					ResultSet rs2=st2.executeQuery("select * from patient where patientId='"+dcm.getPatientId()+"'");
					if(rs2.next()) {
						PatientModel pm = new PatientModel();
						pm.setPatientId(rs2.getString("patientId"));
						pm.setName(rs2.getString("name"));
						pm.setEmail(rs2.getString("email"));
						pm.setPhone(rs2.getString("phone"));
						pm.setAddress(rs2.getString("address"));
						pm.setAge(rs2.getString("age"));
						pm.setGender(rs2.getString("gender"));
						pm.setPurpose(rs2.getString("purpose"));
						pm.setPassword(rs2.getString("password"));
						
						
						dcm.setPm(pm);
					}
					Statement st3 = con.createStatement();
					ResultSet rs3=st3.executeQuery("select * from doctor where doctorId='"+dcm.getDoctorId()+"'");
					if(rs3.next()) {
						DoctorModel dm = new DoctorModel();
						dm.setDoctorId(rs3.getString("doctorId"));
						dm.setFirstname(rs3.getString("firstname"));
						dm.setLastname(rs3.getString("lastname"));
						dm.setEmail(rs3.getString("email"));
						dm.setPhone(rs3.getString("phone"));
						dm.setPassword(rs3.getString("password"));
						dm.setDesignation(rs3.getString("designation"));
						dm.setDesignation(rs3.getString("specialization"));
						dm.setExperiance(rs3.getString("experiance"));
						dm.setDateOfJoining(rs3.getString("dateOfJoining"));
						dm.setShiftStartTime(rs3.getString("shiftStartTime"));
						dm.setShiftEndTime(rs3.getString("shiftEndTime"));
						
					
						
						
						dcm.setDm(dm);
					}
					Statement st4 = con.createStatement();
					ResultSet rs4=st4.executeQuery("select * from laboratory where laboratoryId='"+dcm.getLaboratoryId()+"'");
					if(rs4.next()) {
						LabModel lm=new LabModel();
					lm.setLabname(rs4.getString("labname"));
						dcm.setLm(lm);
					}
					Statement st5 = con.createStatement();
					ResultSet rs5=st5.executeQuery("select * from labTestRequest where labTestRequestId='"+dcm.getLabTestRequestId()+"'");
					if(rs5.next()) {
						LabTestModel ltm=new LabTestModel();
						ltm.setLabTestRequest(rs5.getString("labTestRequest"));
						dcm.setLtm(ltm);
					}
					dList.add(dcm);
				}
				return dList;
			
			} catch (Exception e) {
				System.out.println(e);
				
				 return null;
			}
		   
		   
		  
	   }
}
