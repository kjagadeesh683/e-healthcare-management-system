package hospital.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import hospital.databaseconnection.DBCon;
import hospital.enail.Email;
import hospital.model.FrontOfficeModel;
import hospital.model.LabModel;

public class LabDao {
	public String addLaboratory(LabModel lm) {

		try {
			Connection con = DBCon.getConnection();
			Statement st = con.createStatement();
			int a = st.executeUpdate(
					"insert into laboratory(labname,operatorname,email,phone,password,laboratorytype) values('"
							+ lm.getLabname() + "','" + lm.getOperatorname() + "','" + lm.getEmail() + "','"
							+ lm.getPhone() + "','" + lm.getPassword() + "','" + lm.getLaboratorytype() + "')",Statement.RETURN_GENERATED_KEYS);
			ResultSet rs= st.getGeneratedKeys();
			if(rs.next()) {
				Email.sendEmail("Laboratory Account Created", "Hello "+lm.getLabname()+"  Your Laboratory Account Created. your login creditials are  ID: "+rs.getInt(1)+" and password is: "+lm.getPassword(), lm.getEmail());

			}
			return "Laboratory added Successfully";
		} catch (Exception e) {
			System.out.println(e);
			return "Laboratory adding Failed";
		}

	}
	public List<LabModel> viewLaboratory(String laboratoryId){
		   
		   try {
			   String query = "select * from laboratory";
				if(laboratoryId!=null) {
					query = query +" where laboratoryId='"+laboratoryId+"'";
				}
				Connection con = DBCon.getConnection();
				Statement st = con.createStatement();
				ResultSet rs=st.executeQuery(query);
				List<LabModel> labList =new ArrayList<LabModel>();
				while(rs.next()) {
					LabModel lm=new LabModel();
					lm.setLaboratoryId(rs.getString("laboratoryId"));
					lm.setLabname(rs.getString("labname"));
					lm.setOperatorname(rs.getString("operatorname"));
					lm.setEmail(rs.getString("email"));
					lm.setPhone(rs.getString("phone"));
					lm.setPassword(rs.getString("password"));
					lm.setLaboratorytype(rs.getString("laboratorytype"));
					lm.setStatus(rs.getString("status"));
					labList.add(lm);
				}
				return labList;
			
			} catch (Exception e) {
				System.out.println(e);
				
				 return null;
			}
		   
		  
		  
	   } 
	public Boolean labLogin(String userId,String password,HttpServletResponse response ,HttpSession session) {
		 try {
				Connection con = DBCon.getConnection();
				Statement st = con.createStatement();
				ResultSet rs=st.executeQuery("select * from laboratory where laboratoryId='"+userId+"' and password='"+password+"' ");
				if (rs.next()){
					
					session.setAttribute("laboratoryId",rs.getString("laboratoryId"));
					session.setAttribute("labname",rs.getString("labname"));
					session.setAttribute("operatorname",rs.getString("operatorname"));
					session.setAttribute("role","laboratory");
					session.setAttribute("status", rs.getString("status"));
					if(rs.getString("status").equalsIgnoreCase("Enabled")) {	
						response.sendRedirect("laboratoryHome.jsp");
					} else {
						
						response.sendRedirect("messageFailed.jsp?status=Laboratory not at Enabled");
					}
					 
				}
				else {
					response.sendRedirect("messageFailed.jsp?status=invalied crediantials");
				}
			
			} catch (Exception e) {
				System.out.println(e);
				
				 
			}
		 
		 return false;
		
	 }
	public LabModel editLaboratory(String laboratoryId) {
		try {
			Connection con = DBCon.getConnection();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from laboratory where laboratoryId='" + laboratoryId + "'");

			if (rs.next()) {
				LabModel lm = new LabModel();
				lm.setLaboratoryId(rs.getString("laboratoryId"));
				lm.setLabname(rs.getString("labname"));
				lm.setOperatorname(rs.getString("operatorname"));
				lm.setEmail(rs.getString("email"));
				lm.setPhone(rs.getString("phone"));
				lm.setPassword(rs.getString("password"));
				lm.setLaboratorytype(rs.getString("laboratorytype"));
				return lm;

			}

		} catch (Exception e) {
			System.out.println(e);

		}

		return null;

	}
	public String editParticularLaboratory(LabModel lm) {

		try {
			Connection con = DBCon.getConnection();
			Statement st = con.createStatement();
			int a = st.executeUpdate("update laboratory set labname='"+lm.getLabname()+"',operatorname='"+lm.getOperatorname()+"',email='"+lm.getEmail()+"',phone='"+lm.getPhone()+"',password='"+lm.getPassword()+"',laboratorytype='"+lm.getLaboratorytype()+"'  where laboratoryId='"
					+ lm.getLaboratoryId() + "'");
			return "Laboratory Updated Successfully";
		} catch (Exception e) {
			System.out.println(e);
			return "Laboratory Updating Failed";
		}

	}
	public void laboratoryStatus(String laboratoryId,String status,HttpServletResponse response) {
		String newStatus=null;
		if(status.equalsIgnoreCase("Disabled")) {
			
			newStatus="Enabled";
		}
		else {
			
			newStatus="Disabled";
		}
		
		try {
			Connection con = DBCon.getConnection();
			Statement st = con.createStatement();
			int a = st.executeUpdate("update laboratory set status='"+newStatus+"'   where laboratoryId='"+laboratoryId+"'");
			response.sendRedirect("viewLaboratory.jsp");
		} catch (Exception e) {
			System.out.println(e);
			
		}
		
	}
	
}
