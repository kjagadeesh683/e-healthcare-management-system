package hospital.model;

public class LabTestModel {
	private String labTestRequestId;
	private String labTestRequest;
	private String doctorId;
	private String patientId;
	private String laboratoryId;
	private String status;
	private DoctorModel dm;
	private PatientModel pm;
	private LabModel lm;
	private String datee;
	public String getLabTestRequestId() {
		return labTestRequestId;
	}
	public void setLabTestRequestId(String labTestRequestId) {
		this.labTestRequestId = labTestRequestId;
	}
	public String getLabTestRequest() {
		return labTestRequest;
	}
	public void setLabTestRequest(String labTestRequest) {
		this.labTestRequest = labTestRequest;
	}
	public String getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(String doctorId) {
		this.doctorId = doctorId;
	}
	public String getPatientId() {
		return patientId;
	}
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}
	public String getLaboratoryId() {
		return laboratoryId;
	}
	public void setLaboratoryId(String laboratoryId) {
		this.laboratoryId = laboratoryId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public DoctorModel getDm() {
		return dm;
	}
	public void setDm(DoctorModel dm) {
		this.dm = dm;
	}
	public PatientModel getPm() {
		return pm;
	}
	public void setPm(PatientModel pm) {
		this.pm = pm;
	}
	public String getDatee() {
		return datee;
	}
	public void setDatee(String datee) {
		this.datee = datee;
	}
	public LabModel getLm() {
		return lm;
	}
	public void setLm(LabModel lm) {
		this.lm = lm;
	}
	
}
