package hospital.model;

public class ReadingsModel {
	private String readingId;
	private String readingName;
	private String readingValue;
	private String status;
	private String doctorId;
	private String patientId;
	private DoctorModel dm;
	private PatientModel pm;
	private String datee;
	
	
	
	
	
	public String getDatee() {
		return datee;
	}
	public void setDatee(String datee) {
		this.datee = datee;
	}
	public DoctorModel getDm() {
		return dm;
	}
	public void setDm(DoctorModel dm) {
		this.dm = dm;
	}
	public PatientModel getPm() {
		return pm;
	}
	public void setPm(PatientModel pm) {
		this.pm = pm;
	}
	public String getReadingId() {
		return readingId;
	}
	public void setReadingId(String readingId) {
		this.readingId = readingId;
	}
	public String getReadingName() {
		return readingName;
	}
	public void setReadingName(String readingName) {
		this.readingName = readingName;
	}
	public String getReadingValue() {
		return readingValue;
	}
	public void setReadingValue(String readingValue) {
		this.readingValue = readingValue;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(String doctorId) {
		this.doctorId = doctorId;
	}
	public String getPatientId() {
		return patientId;
	}
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}
	

}
