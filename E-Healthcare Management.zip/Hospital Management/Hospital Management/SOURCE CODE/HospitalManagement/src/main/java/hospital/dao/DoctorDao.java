package hospital.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import hospital.databaseconnection.DBCon;
import hospital.enail.Email;
import hospital.model.DoctorModel;

public class DoctorDao {
	public String addDoctors(DoctorModel dm) {

		try {
			Connection con = DBCon.getConnection();
			Statement st = con.createStatement();
			int a = st.executeUpdate(
					"insert into doctor(firstname,lastname,email,phone,password,designation,specialization,experiance,dateOfJoining,shiftStartTime,shiftEndTime) values('"
							+ dm.getFirstname() + "','" + dm.getLastname() + "','" + dm.getEmail() + "','"
							+ dm.getPhone() + "','" + dm.getPassword() + "','" + dm.getDesignation() + "','"
							+ dm.getSpecialization() + "','" + dm.getExperiance() + "','" + dm.getDateOfJoining()
							+ "','" + dm.getShiftStartTime() + "','" + dm.getShiftEndTime() + "')",Statement.RETURN_GENERATED_KEYS);
			ResultSet rs= st.getGeneratedKeys();
			if(rs.next()) {
				Email.sendEmail("Doctor Account Created", "Hello "+dm.getFirstname()+" "+dm.getLastname()+" Your Doctor Account Created. your login creditials are Doctor ID: "+rs.getInt(1)+" and password is: "+dm.getPassword(), dm.getEmail());

			}
			
			return "Doctor added Successfully";
		} catch (Exception e) {
			System.out.println(e);
			return "Doctor adding Failed";
		}

	}

	public List<DoctorModel> viewDoctor(String doctorId) {
		List<DoctorModel> docList = new ArrayList<DoctorModel>();
		try {
			String query = "select * from doctor";
			if(doctorId!=null) {
				query = query +" where doctorId='"+doctorId+"'";
			}
			Connection con = DBCon.getConnection();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(query);
			
			while (rs.next()) {
				DoctorModel dm = new DoctorModel();
				dm.setDoctorId(rs.getString("doctorId"));
				dm.setFirstname(rs.getString("firstname"));
				dm.setLastname(rs.getString("lastname"));
				dm.setEmail(rs.getString("email"));
				dm.setPhone(rs.getString("phone"));
				dm.setPassword(rs.getString("password"));
				dm.setDesignation(rs.getString("designation"));
				dm.setSpecialization(rs.getString("specialization"));
				dm.setExperiance(rs.getString("experiance"));
				dm.setDateOfJoining(rs.getString("dateOfJoining"));
				dm.setShiftStartTime(rs.getString("shiftStartTime"));
				dm.setShiftEndTime(rs.getString("shiftEndTime"));
				dm.setStatus(rs.getString("status"));
				docList.add(dm);
			}
			return docList;

		} catch (Exception e) {
			System.out.println(e);

			return docList;
		}

	}

	public Boolean doctorLogin(String userId, String password, HttpServletResponse response, HttpSession session) {
		try {
			Connection con = DBCon.getConnection();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(
					"select * from doctor where doctorId='" + userId + "' and password='" + password + "'");
			if (rs.next()) {

				session.setAttribute("doctorId", rs.getString("doctorId"));
				session.setAttribute("name", rs.getString("firstname")+" "+rs.getString("lastname"));
				session.setAttribute("role", "doctor");
				session.setAttribute("status", rs.getString("status"));
				if(rs.getString("status").equalsIgnoreCase("Enabled")) {	
					response.sendRedirect("doctorHome.jsp");
				} else {
					
					response.sendRedirect("messageFailed.jsp?status=Doctor not at Enabled");
				}

			} else {
				response.sendRedirect("messageFailed.jsp?status=invalied crediantials");
			}

		} catch (Exception e) {
			System.out.println(e);

		}

		return false;

	}

	public DoctorModel editDoctor(String doctorId) {
		try {
			Connection con = DBCon.getConnection();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from doctor where doctorId='" + doctorId + "'");

			if (rs.next()) {
				DoctorModel dm = new DoctorModel();
				dm.setDoctorId(rs.getString("doctorId"));
				dm.setFirstname(rs.getString("firstname"));
				dm.setLastname(rs.getString("lastname"));
				dm.setEmail(rs.getString("email"));
				dm.setPhone(rs.getString("phone"));
				dm.setPassword(rs.getString("password"));
				dm.setDesignation(rs.getString("designation"));
				dm.setSpecialization(rs.getString("specialization"));
				dm.setExperiance(rs.getString("experiance"));
				dm.setDateOfJoining(rs.getString("dateOfJoining"));
				dm.setShiftStartTime(rs.getString("shiftStartTime"));
				dm.setShiftEndTime(rs.getString("shiftEndTime"));
				
				return dm;
			}

		} catch (Exception e) {
			System.out.println(e);

		}

		return null;

	}

	public String editParticularDoctor(DoctorModel dm) {

		try {
			Connection con = DBCon.getConnection();
			Statement st = con.createStatement();
			int a = st.executeUpdate("update doctor set firstname='" + dm.getFirstname() + "',lastname='"
					+ dm.getLastname() + "',email='" + dm.getEmail() + "',phone='" + dm.getPhone() + "',password='"
					+ dm.getPassword() + "',designation='" + dm.getDesignation() + "',specialization='"
					+ dm.getSpecialization() + "',experiance='" + dm.getExperiance() + "',dateOfJoining='"
					+ dm.getDateOfJoining() + "',shiftStartTime='" + dm.getShiftStartTime() + "',shiftEndTime='"
					+ dm.getShiftEndTime() + "'  where doctorId='"+dm.getDoctorId()+"'");
			return "Doctor Updated Successfully";
		} catch (Exception e) {
			System.out.println(e);
			return "Doctor Updating Failed";
		}

	}
	
	public void doctorStatus(String doctorId,String status,HttpServletResponse response) {
		String newStatus=null;
		if(status.equalsIgnoreCase("Disabled")) {
			
			newStatus="Enabled";
		}
		else {
			
			newStatus="Disabled";
		}
		
		try {
			Connection con = DBCon.getConnection();
			Statement st = con.createStatement();
			int a = st.executeUpdate("update doctor set status='"+newStatus+"'   where doctorId='"+doctorId+"'");
			response.sendRedirect("viewDoctor.jsp");
		} catch (Exception e) {
			System.out.println(e);
			
		}
		
	}
}
