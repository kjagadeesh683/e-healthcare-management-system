package hospital.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import hospital.databaseconnection.DBCon;
import hospital.enail.Email;
import hospital.model.FrontOfficeModel;
import hospital.model.MStoreModel;

public class MStoreDao {
	public String addMedicalStore(MStoreModel msm) {

		try {
			Connection con = DBCon.getConnection();
			Statement st = con.createStatement();
			int a = st.executeUpdate(
					"insert into medicalStore(medicalstorename,operatorname,email,phone,password) values('"
							+ msm.getMedicalstorename() + "','" + msm.getOperatorname() + "','" + msm.getEmail() + "','"
							+ msm.getPhone() + "','" + msm.getPassword() + "')",Statement.RETURN_GENERATED_KEYS);
			ResultSet rs= st.getGeneratedKeys();
			if(rs.next()) {
				Email.sendEmail("Medical Store Account Created", "Hello "+ msm.getMedicalstorename()+"  Your Medical Store Account Created. your login creditials are  ID: "+rs.getInt(1)+" and password is: "+msm.getPassword(), msm.getEmail());

			}
			return "Medical Store added Successfully";
		} catch (Exception e) {
			System.out.println(e);
			return "Medical Store adding Failed";
		}

	}
	public List<MStoreModel> viewMedicalStore(String medicalStoreId){
		   
		   try {
				String query = "select * from medicalStorer";
				if(medicalStoreId!=null) {
					query = query +" where medicalStoreId='"+medicalStoreId+"'";
				}
				Connection con = DBCon.getConnection();
				Statement st = con.createStatement();
				ResultSet rs=st.executeQuery("select * from medicalStore");
				List<MStoreModel> msList =new ArrayList<MStoreModel>();
				while(rs.next()) {
					MStoreModel msm=new MStoreModel();
					msm.setMedicalStoreId(rs.getString("medicalStoreId"));
					msm.setMedicalstorename(rs.getString("medicalstorename"));
					msm.setOperatorname(rs.getString("operatorname"));
					msm.setEmail(rs.getString("email"));
					msm.setPhone(rs.getString("phone"));
					msm.setPassword(rs.getString("password"));
					msm.setStatus(rs.getString("status"));
					
					msList.add(msm);
				}
				return msList;
			
			} catch (Exception e) {
				System.out.println(e);
				
				 return null;
			}
		   
		   
		  
	   } 
	public Boolean msLogin(String userId,String password,HttpServletResponse response ,HttpSession session) {
		 try {
				Connection con = DBCon.getConnection();
				Statement st = con.createStatement();
				ResultSet rs=st.executeQuery("select * from medicalStore where medicalStoreId='"+userId+"' and password='"+password+"'");
				if (rs.next()){
					
					session.setAttribute("medicalStoreId",rs.getString("medicalStoreId"));
					session.setAttribute("medicalstorename",rs.getString("medicalstorename"));
					session.setAttribute("operatorname",rs.getString("operatorname"));
					session.setAttribute("role","MedicalStore");
					session.setAttribute("status", rs.getString("status"));
					if(rs.getString("status").equalsIgnoreCase("Enabled")) {	
						response.sendRedirect("msHome.jsp");
					} else {
						
						response.sendRedirect("messageFailed.jsp?status=Medical Store not at Enabled");
					}
					 
					 
				}
				else {
					response.sendRedirect("messageFailed.jsp?status=invalied crediantials");
				}
			
			} catch (Exception e) {
				System.out.println(e);
				
				 
			}
		 
		 return false;
		
	 }
	public MStoreModel editMStore(String medicalStoreId) {
		try {
			Connection con = DBCon.getConnection();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from medicalStore where medicalStoreId='" + medicalStoreId + "'");

			if (rs.next()) {
				MStoreModel msm = new MStoreModel();
				msm.setMedicalStoreId(rs.getString("medicalStoreId"));
				msm.setMedicalstorename(rs.getString("medicalstorename"));
				msm.setOperatorname(rs.getString("operatorname"));
				msm.setEmail(rs.getString("email"));
				msm.setPhone(rs.getString("phone"));
				msm.setPassword(rs.getString("password"));
				return msm;

			}

		} catch (Exception e) {
			System.out.println(e);

		}

		return null;

	}
	public String editParticularMStore(MStoreModel msm) {

		try {
			Connection con = DBCon.getConnection();
			Statement st = con.createStatement();
			int a = st.executeUpdate("update medicalStore set medicalstorename='" + msm.getMedicalstorename()
					+ "',operatorname='" + msm.getOperatorname() + "',email='" + msm.getEmail() + "',phone='"
					+ msm.getPhone() + "',password='" + msm.getPassword() + "'  where medicalStoreId='"
					+ msm.getMedicalStoreId() + "'");
			return "MedicalStore Updated Successfully";
		} catch (Exception e) {
			System.out.println(e);
			return "MedicalStore Updating Failed";
		}

	}
	public void mStoreStatus(String medicalStoreId,String status,HttpServletResponse response) {
		String newStatus=null;
		if(status.equalsIgnoreCase("Disabled")) {
			
			newStatus="Enabled";
		}
		else {
			
			newStatus="Disabled";
		}
		
		try {
			Connection con = DBCon.getConnection();
			Statement st = con.createStatement();
			int a = st.executeUpdate("update medicalStore set status='"+newStatus+"'   where medicalStoreId='"+medicalStoreId+"'");
			response.sendRedirect("viewMedicalStore.jsp");
		} catch (Exception e) {
			System.out.println(e);
			
		}
		
	}
}
