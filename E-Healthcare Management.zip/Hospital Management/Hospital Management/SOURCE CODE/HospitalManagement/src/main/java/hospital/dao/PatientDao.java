package hospital.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.catalina.connector.Response;

import hospital.databaseconnection.DBCon;
import hospital.enail.Email;
import hospital.model.FrontOfficeModel;
import hospital.model.PatientModel;

public class PatientDao {
	public String addPatientORGuardian(PatientModel pm) {

		try {
			Connection con = DBCon.getConnection();
			Statement st = con.createStatement();
			int a = st
					.executeUpdate("insert into patient(name,email,phone,address,age,gender,purpose,password) values('"
							+ pm.getName() + "','" + pm.getEmail() + "','" + pm.getPhone() + "','" + pm.getAddress()
							+ "','" + pm.getAge() + "','" + pm.getGender() + "','" + pm.getPurpose() + "','"
							+ pm.getPassword() + "')",Statement.RETURN_GENERATED_KEYS);
			ResultSet rs= st.getGeneratedKeys();
			if(rs.next()) {
				Email.sendEmail("Patient Account Created", "Hello "+ pm.getName() +"  Your Patient Account Created. your login creditials are  ID: "+pm.getPhone()+" and password is: "+pm.getPassword(), pm.getEmail());

			}
			return "Patient/Guardian added Successfully";
		} catch (Exception e) {
			System.out.println(e);
			return "Patient/Guardian adding Failed";
		}

	}
	public List<PatientModel> viewPatientORGuardian() {

		try {
			Connection con = DBCon.getConnection();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from patient");
			List<PatientModel> pList = new ArrayList<PatientModel>();
			while (rs.next()) {
				PatientModel pm = new PatientModel();
				pm.setPatientId(rs.getString("patientId"));
				pm.setName(rs.getString("name"));
				pm.setEmail(rs.getString("email"));
				pm.setPhone(rs.getString("phone"));
				pm.setAddress(rs.getString("address"));
				pm.setAge(rs.getString("age"));
				pm.setGender(rs.getString("gender"));
				pm.setPurpose(rs.getString("purpose"));
				pm.setPassword(rs.getString("password"));

				pList.add(pm);
			}
			return pList;

		} catch (Exception e) {
			System.out.println(e);

			return null;
		}

	}

	public Boolean patientORGuardianLogin(String phone, String password, HttpServletResponse response, HttpSession session) {
		try {
			Connection con = DBCon.getConnection();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(
					"select * from patient where phone='" + phone + "' and password='" + password + "'");
			if (rs.next()) {
				session.setAttribute("patientId", rs.getString("patientId"));
				session.setAttribute("phone", rs.getString("phone"));
				session.setAttribute("role", "patient");
				response.sendRedirect("patientHome.jsp");
				

			} else {
				response.sendRedirect("messageFailed.jsp?status=invalied crediantials");
			}

		} catch (Exception e) {
			System.out.println(e);

		}

		return false;

	}
	public PatientModel editPatientORGuardian(String patientId) {
		try {
			Connection con = DBCon.getConnection();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from patient where patientId='" + patientId + "'");

			if (rs.next()) {
				PatientModel pm = new PatientModel();				
				pm.setPatientId(rs.getString("patientId"));
				pm.setName(rs.getString("name"));
				pm.setEmail(rs.getString("email"));
				pm.setPhone(rs.getString("phone"));
				pm.setAddress(rs.getString("address"));
				pm.setAge(rs.getString("age"));
				pm.setGender(rs.getString("gender"));
				pm.setPurpose(rs.getString("purpose"));
				pm.setPassword(rs.getString("password"));
				return pm;

			}

		} catch (Exception e) {
			System.out.println(e);

		}

		return null;

	}
	public String editParticularPatientORGuardian(PatientModel pm) {

		try {
			Connection con = DBCon.getConnection();
			Statement st = con.createStatement();
			int a = st.executeUpdate("update patient set name='"+pm.getName()+"',email='"+pm.getEmail()+"',phone='"+pm.getPhone()+"',address='"+pm.getAddress()+"',age='"+pm.getAge()+"',gender='"+pm.getGender()+"',purpose='"+pm.getPurpose()+"',password='"+pm.getPassword()+"'   where patientId='"
					+ pm.getPatientId() + "'");
			return "Patient/Guardian Updated Successfully";
		} catch (Exception e) {
			System.out.println(e);
			return "Patient Updating Failed";
		}

	}
	public List<PatientModel> getPatients(String keyword,String searchType){
		String query=null;
		if(searchType.equalsIgnoreCase("id")){
			
			query="select * from patient where patientId='"+keyword+"'";
		}else {
			query="select * from patient where name like '%"+keyword+"%'";
		}
		try {
			Connection con = DBCon.getConnection();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(query);
			List<PatientModel> pList = new ArrayList<PatientModel>();
			while (rs.next()) {
				PatientModel pm = new PatientModel();
				pm.setPatientId(rs.getString("patientId"));
				pm.setName(rs.getString("name"));
				pm.setEmail(rs.getString("email"));
				pm.setPhone(rs.getString("phone"));
				pm.setAddress(rs.getString("address"));
				pm.setAge(rs.getString("age"));
				pm.setGender(rs.getString("gender"));
				pm.setPurpose(rs.getString("purpose"));
				pList.add(pm);
			}
			return pList;
			
		} catch (Exception e) {
			System.out.println(e);

			return null;
		}
		
		
		
		
	}
	
}
