package hospital.model;

public class MStoreModel {
	private String medicalStoreId;
	private String medicalstorename;
	private String operatorname;
	private String email;
	private String phone;
	private String password;
	private String status;
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMedicalStoreId() {
		return medicalStoreId;
	}
	public void setMedicalStoreId(String medicalStoreId) {
		this.medicalStoreId = medicalStoreId;
	}
	public String getMedicalstorename() {
		return medicalstorename;
	}
	public void setMedicalstorename(String medicalstorename) {
		this.medicalstorename = medicalstorename;
	}
	public String getOperatorname() {
		return operatorname;
	}
	public void setOperatorname(String operatorname) {
		this.operatorname = operatorname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}


}
