package hospital.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import hospital.databaseconnection.DBCon;
import hospital.model.DoctorModel;
import hospital.model.HealthUpdateModel;
import hospital.model.PatientModel;
public class HealthUpdateDao {
	public String addHealthUpdate(HealthUpdateModel hm) {
		try {
			Connection con = DBCon.getConnection();
			Statement st = con.createStatement();
			int a = st.executeUpdate(
					"insert into healthUpdate(healthUpdate,doctorId,patientId) values('"+hm.getHealthUpdate()+"','"+hm.getDoctorId()+"','"+hm.getPatientId()+"')");
			return "HealthUpdate added Successfully";
		} catch (Exception e) {
			System.out.println(e);
			return "HealthUpdate adding Failed";
		}
		
		
	}
	public List<HealthUpdateModel> viewHealthUpdate(String patientId ){
		   
		   try {
				Connection con = DBCon.getConnection();
				Statement st = con.createStatement();
				ResultSet rs=st.executeQuery("select * from healthUpdate where patientId='"+patientId+"'");
				List<HealthUpdateModel> hList =new ArrayList<HealthUpdateModel>();
				while(rs.next()) {
					HealthUpdateModel hm=new HealthUpdateModel();
					hm.setDoctorId(rs.getString("doctorId"));
					hm.setPatientId(rs.getString("patientId"));
					hm.setHealthUpdateId(rs.getString("healthUpdateId"));
					hm.setHealthUpdate(rs.getString("healthUpdate"));
					hm.setDatee(rs.getString("datee"));
					Statement st2 = con.createStatement();
					ResultSet rs2=st2.executeQuery("select * from patient where patientId='"+patientId+"'");
					if(rs2.next()) {
						PatientModel pm = new PatientModel();
						pm.setPatientId(rs2.getString("patientId"));
						pm.setName(rs2.getString("name"));
						pm.setEmail(rs2.getString("email"));
						pm.setPhone(rs2.getString("phone"));
						pm.setAddress(rs2.getString("address"));
						pm.setAge(rs2.getString("age"));
						pm.setGender(rs2.getString("gender"));
						pm.setPurpose(rs2.getString("purpose"));
						pm.setPassword(rs2.getString("password"));
						
						
						hm.setPm(pm);
					}
					Statement st3 = con.createStatement();
					ResultSet rs3=st3.executeQuery("select * from doctor where doctorId='"+hm.getDoctorId()+"'");
					if(rs3.next()) {
						DoctorModel dm = new DoctorModel();
						dm.setDoctorId(rs3.getString("doctorId"));
						dm.setFirstname(rs3.getString("firstname"));
						dm.setLastname(rs3.getString("lastname"));
						dm.setEmail(rs3.getString("email"));
						dm.setPhone(rs3.getString("phone"));
						dm.setPassword(rs3.getString("password"));
						dm.setDesignation(rs3.getString("designation"));
						dm.setDesignation(rs3.getString("specialization"));
						dm.setExperiance(rs3.getString("experiance"));
						dm.setDateOfJoining(rs3.getString("dateOfJoining"));
						dm.setShiftStartTime(rs3.getString("shiftStartTime"));
						dm.setShiftEndTime(rs3.getString("shiftEndTime"));
						
					
						
						
						hm.setDm(dm);
					}
					hList.add(hm);
				}
				return hList;
			
			} catch (Exception e) {
				System.out.println(e);
				
				 return null;
			}
		   
		   
		  
	   }
}
