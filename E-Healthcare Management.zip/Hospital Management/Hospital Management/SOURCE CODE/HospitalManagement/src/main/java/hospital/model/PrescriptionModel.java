package hospital.model;

public class PrescriptionModel {
	private String PrescriptionId;
	private String Prescription;
	private String doctorId;
	private String patientId;
	private String medicalStoreId;
	private String status;
	private DoctorModel dm;
	private PatientModel pm;
	private String datee;
	private MStoreModel msm;
	
	public String getMedicalStoreId() {
		return medicalStoreId;
	}
	public void setMedicalStoreId(String medicalStoreId) {
		this.medicalStoreId = medicalStoreId;
	}
	public String getPrescriptionId() {
		return PrescriptionId;
	}
	public void setPrescriptionId(String prescriptionId) {
		PrescriptionId = prescriptionId;
	}
	public String getPrescription() {
		return Prescription;
	}
	public void setPrescription(String prescription) {
		Prescription = prescription;
	}
	public String getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(String doctorId) {
		this.doctorId = doctorId;
	}
	public String getPatientId() {
		return patientId;
	}
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}
	public DoctorModel getDm() {
		return dm;
	}
	public void setDm(DoctorModel dm) {
		this.dm = dm;
	}
	public PatientModel getPm() {
		return pm;
	}
	public void setPm(PatientModel pm) {
		this.pm = pm;
	}
	public String getDatee() {
		return datee;
	}
	public void setDatee(String datee) {
		this.datee = datee;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public MStoreModel getMsm() {
		return msm;
	}
	public void setMsm(MStoreModel msm) {
		this.msm = msm;
	}
	
}
