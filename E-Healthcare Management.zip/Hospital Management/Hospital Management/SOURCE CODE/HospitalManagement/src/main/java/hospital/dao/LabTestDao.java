package hospital.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import hospital.databaseconnection.DBCon;
import hospital.model.DoctorModel;
import hospital.model.LabModel;
import hospital.model.LabTestModel;
import hospital.model.PatientModel;

public class LabTestDao {
	public String addlabTestRequest(LabTestModel ltm) {
		try {
			Connection con = DBCon.getConnection();
			Statement st = con.createStatement();
			int a = st.executeUpdate(
					"insert into labTestRequest(labTestRequest,doctorId,patientId,laboratoryId) values('"+ltm.getLabTestRequest()+"','"+ltm.getDoctorId()+"','"+ltm.getPatientId()+"','"+ltm.getLaboratoryId()+"')");
			return "LabTest added Successfully";
		} catch (Exception e) {
			System.out.println(e);
			return "LabTest adding Failed";
		}
		
		
	} 
	public List<LabTestModel> viewLabTest(String patientId,String laboratoryId,String type){
		   
		   try {
			   String query = "select * from labTestRequest where patientId='"+patientId+"'";
			   if(laboratoryId!=null) {
				   query ="select * from labTestRequest where laboratoryId='"+laboratoryId+"'";
			   }
				Connection con = DBCon.getConnection();
				Statement st = con.createStatement();
				ResultSet rs=st.executeQuery(query);
				List<LabTestModel> ltList =new ArrayList<LabTestModel>();
				while(rs.next()) {
					LabTestModel ltm=new LabTestModel();
					ltm.setDoctorId(rs.getString("doctorId"));
					ltm.setPatientId(rs.getString("patientId"));
					ltm.setLabTestRequestId(rs.getString("labTestRequestId"));
					ltm.setLabTestRequest(rs.getString("labTestRequest"));
					ltm.setDatee(rs.getString("datee"));
					ltm.setStatus(rs.getString("status"));
					ltm.setLaboratoryId(rs.getString("laboratoryId"));
					Statement st2 = con.createStatement();
					ResultSet rs2=st2.executeQuery("select * from patient where patientId='"+ltm.getPatientId()+"'");
					if(rs2.next()) {
						PatientModel pm = new PatientModel();
						pm.setPatientId(rs2.getString("patientId"));
						pm.setName(rs2.getString("name"));
						pm.setEmail(rs2.getString("email"));
						pm.setPhone(rs2.getString("phone"));
						pm.setAddress(rs2.getString("address"));
						pm.setAge(rs2.getString("age"));
						pm.setGender(rs2.getString("gender"));
						pm.setPurpose(rs2.getString("purpose"));
						pm.setPassword(rs2.getString("password"));
						
						
						ltm.setPm(pm);
					}
					Statement st3 = con.createStatement();
					ResultSet rs3=st3.executeQuery("select * from doctor where doctorId='"+ltm.getDoctorId()+"'");
					if(rs3.next()) {
						DoctorModel dm = new DoctorModel();
						dm.setDoctorId(rs3.getString("doctorId"));
						dm.setFirstname(rs3.getString("firstname"));
						dm.setLastname(rs3.getString("lastname"));
						dm.setEmail(rs3.getString("email"));
						dm.setPhone(rs3.getString("phone"));
						dm.setPassword(rs3.getString("password"));
						dm.setDesignation(rs3.getString("designation"));
						dm.setDesignation(rs3.getString("specialization"));
						dm.setExperiance(rs3.getString("experiance"));
						dm.setDateOfJoining(rs3.getString("dateOfJoining"));
						dm.setShiftStartTime(rs3.getString("shiftStartTime"));
						dm.setShiftEndTime(rs3.getString("shiftEndTime"));
						ltm.setDm(dm);
					}
					Statement st4 = con.createStatement();
					System.out.println("select * from laboratory where laboratoryId='"+ltm.getLaboratoryId()+"'");
					ResultSet rs4=st4.executeQuery("select * from laboratory where laboratoryId='"+ltm.getLaboratoryId()+"'");
					if(rs4.next()) {
						LabModel lm = new LabModel();
						lm.setLabname(rs4.getString("labname"));
						lm.setEmail(rs4.getString("email"));
						lm.setLaboratorytype(rs4.getString("laboratorytype"));
						lm.setOperatorname(rs4.getString("operatorname"));
						lm.setPhone(rs4.getString("phone"));
						ltm.setLm(lm);
					}
					
					if(type.equalsIgnoreCase("new")&&ltm.getStatus().equalsIgnoreCase("Requested")) {
						ltList.add(ltm);
					}else if(type.equalsIgnoreCase("history") && ltm.getStatus().equalsIgnoreCase("Uploaded")) {
						ltList.add(ltm);
					} else if(type.equalsIgnoreCase("all")) {
						ltList.add(ltm);
					}
					
				}
				return ltList;
			
			} catch (Exception e) {
				System.out.println(e);
				
				 return null;
			}
		   
		   
		  
	   }
	public void submitTestReports(String labTestRequestId,HttpServletResponse response) {
		try {
			Connection con = DBCon.getConnection();
			Statement st = con.createStatement();
			int a = st.executeUpdate("update labTestRequest set status='Uploaded' where labTestRequestId='"+labTestRequestId+"'");
			response.sendRedirect("viewLabReports.jsp?type=history");
		} catch (Exception e) {
			System.out.println(e);
			
		}
	}
}
