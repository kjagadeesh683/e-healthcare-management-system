package hospital.model;

public class DoctorModel {
	    private String doctorId;
		private String firstname;
		private String lastname;
		private String email;
		private String phone;
		private String password;
		private String designation;
		private String specialization;
		private String experiance;
		private String dateOfJoining;
		private String shiftStartTime;
		private String shiftEndTime;
		private String status;
		public String getDoctorId() {
			return doctorId;
		}
		public void setDoctorId(String doctorId) {
			this.doctorId = doctorId;
		}
		public String getFirstname() {
			return firstname;
		}
		public void setFirstname(String firstname) {
			this.firstname = firstname;
		}
		public String getLastname() {
			return lastname;
		}
		public void setLastname(String lastname) {
			this.lastname = lastname;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getPhone() {
			return phone;
		}
		public void setPhone(String phone) {
			this.phone = phone;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getDesignation() {
			return designation;
		}
		public void setDesignation(String designation) {
			this.designation = designation;
		}
		public String getSpecialization() {
			return specialization;
		}
		public void setSpecialization(String specialization) {
			this.specialization = specialization;
		}
		public String getExperiance() {
			return experiance;
		}
		public void setExperiance(String experiance) {
			this.experiance = experiance;
		}
		public String getDateOfJoining() {
			return dateOfJoining;
		}
		public void setDateOfJoining(String dateOfJoining) {
			this.dateOfJoining = dateOfJoining;
		}
		public String getShiftStartTime() {
			return shiftStartTime;
		}
		public void setShiftStartTime(String shiftStartTime) {
			this.shiftStartTime = shiftStartTime;
		}
		public String getShiftEndTime() {
			return shiftEndTime;
		}
		public void setShiftEndTime(String shiftEndTime) {
			this.shiftEndTime = shiftEndTime;
		}
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		
		
}
