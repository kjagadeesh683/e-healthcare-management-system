package hospital.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.catalina.connector.Response;

import hospital.databaseconnection.DBCon;
import hospital.model.DoctorModel;
import hospital.model.MStoreModel;
import hospital.model.PatientModel;
import hospital.model.PrescriptionModel;

public class PrescriptionDao {
	public String addPrescription(PrescriptionModel pm) {
		try {
			Connection con = DBCon.getConnection();
			Statement st = con.createStatement();
			int a = st.executeUpdate(
					"insert into Prescription(Prescription,doctorId,patientId,medicalStoreId) values('"+pm.getPrescription()+"','"+pm.getDoctorId()+"','"+pm.getPatientId()+"','"+pm.getMedicalStoreId()+"')");
			return "Prescription added Successfully";
		} catch (Exception e) {
			System.out.println(e);
			return "Prescription adding Failed";
		}
		
		
	}
	public List<PrescriptionModel> viewPrescription(String patientId,String medicalStoreId,String type){
		   
		   try {
			   
			   String query = "select * from Prescription where patientId='"+patientId+"'";
			   if(medicalStoreId!=null) {
				   query = "select * from Prescription where medicalStoreId='"+medicalStoreId+"'";
			   }
			  
				Connection con = DBCon.getConnection();
				Statement st = con.createStatement();
				ResultSet rs=st.executeQuery(query);
				List<PrescriptionModel> pList =new ArrayList<PrescriptionModel>();
				while(rs.next()) {
					PrescriptionModel pcm=new PrescriptionModel();
					pcm.setDoctorId(rs.getString("doctorId"));
					pcm.setPatientId(rs.getString("patientId"));
					pcm.setPrescriptionId(rs.getString("PrescriptionId"));
					pcm.setPrescription(rs.getString("Prescription"));
					pcm.setDatee(rs.getString("datee"));
					pcm.setStatus(rs.getString("status"));
					pcm.setMedicalStoreId(rs.getString("medicalStoreId"));
					Statement st2 = con.createStatement();
					ResultSet rs2=st2.executeQuery("select * from patient where patientId='"+pcm.getPatientId()+"'");
					if(rs2.next()) {
						
						PatientModel pm = new PatientModel();
						pm.setPatientId(rs2.getString("patientId"));
						pm.setName(rs2.getString("name"));
						pm.setEmail(rs2.getString("email"));
						pm.setPhone(rs2.getString("phone"));
						pm.setAddress(rs2.getString("address"));
						pm.setAge(rs2.getString("age"));
						pm.setGender(rs2.getString("gender"));
						pm.setPurpose(rs2.getString("purpose"));
						pm.setPassword(rs2.getString("password"));
						
						
						pcm.setPm(pm);
					}
					Statement st3 = con.createStatement();
					ResultSet rs3=st3.executeQuery("select * from doctor where doctorId='"+pcm.getDoctorId()+"'");
					if(rs3.next()) {
						DoctorModel dm = new DoctorModel();
						dm.setDoctorId(rs3.getString("doctorId"));
						dm.setFirstname(rs3.getString("firstname"));
						dm.setLastname(rs3.getString("lastname"));
						dm.setEmail(rs3.getString("email"));
						dm.setPhone(rs3.getString("phone"));
						dm.setPassword(rs3.getString("password"));
						dm.setDesignation(rs3.getString("designation"));
						dm.setDesignation(rs3.getString("specialization"));
						dm.setExperiance(rs3.getString("experiance"));
						dm.setDateOfJoining(rs3.getString("dateOfJoining"));
						dm.setShiftStartTime(rs3.getString("shiftStartTime"));
						dm.setShiftEndTime(rs3.getString("shiftEndTime"));
						pcm.setDm(dm);
					}
					Statement st4 = con.createStatement();
					ResultSet rs4=st4.executeQuery("select * from medicalStore where medicalStoreId='"+pcm.getMedicalStoreId()+"'");
					if(rs4.next()) {
						MStoreModel msm = new MStoreModel();
						msm.setMedicalStoreId(rs4.getString("medicalStoreId"));
						msm.setMedicalstorename(rs4.getString("medicalstorename"));
						msm.setOperatorname(rs4.getString("operatorname"));
						msm.setEmail(rs4.getString("email"));
						msm.setPhone(rs4.getString("phone"));
						msm.setStatus(rs4.getString("status"));
						pcm.setMsm(msm);
					}
					if(type.equalsIgnoreCase("new")&&pcm.getStatus().equalsIgnoreCase("prescribed")) {
						pList.add(pcm);
					} else if(type.equalsIgnoreCase("history")&&pcm.getStatus().equalsIgnoreCase("Delivered")){
						pList.add(pcm);
					} else if(type.equalsIgnoreCase("all")) {
						pList.add(pcm);
					}
					
				}
				return pList;
			
			} catch (Exception e) {
				System.out.println(e);
				
				 return null;
			}
		   
		   
		  
	   }
	
	public String updatePrescriptionStatus(String PrescriptionId,HttpServletResponse response ) {
		try {
			Connection con = DBCon.getConnection();
			Statement st = con.createStatement();
			int a = st.executeUpdate("update Prescription set status='Delivered'   where PrescriptionId='"+PrescriptionId+"'");
			response.sendRedirect("medicalStoreMessageSuccess.jsp" );
		} catch (Exception e) {
			System.out.println(e);
			
		}
		return null;
	}

}
