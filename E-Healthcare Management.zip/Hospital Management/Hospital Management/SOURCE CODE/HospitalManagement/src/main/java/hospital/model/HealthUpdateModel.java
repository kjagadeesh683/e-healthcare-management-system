package hospital.model;

public class HealthUpdateModel {
	private String healthUpdateId;
	private String healthUpdate;
	private String doctorId;
	private String patientId;
	private DoctorModel dm;
	private PatientModel pm;
	private String datee;
	public String getHealthUpdateId() {
		return healthUpdateId;
	}
	public void setHealthUpdateId(String healthUpdateId) {
		this.healthUpdateId = healthUpdateId;
	}
	public String getHealthUpdate() {
		return healthUpdate;
	}
	public void setHealthUpdate(String healthUpdate) {
		this.healthUpdate = healthUpdate;
	}
	public String getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(String doctorId) {
		this.doctorId = doctorId;
	}
	public String getPatientId() {
		return patientId;
	}
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}
	public DoctorModel getDm() {
		return dm;
	}
	public void setDm(DoctorModel dm) {
		this.dm = dm;
	}
	public PatientModel getPm() {
		return pm;
	}
	public void setPm(PatientModel pm) {
		this.pm = pm;
	}
	public String getDatee() {
		return datee;
	}
	public void setDatee(String datee) {
		this.datee = datee;
	}
	
}
