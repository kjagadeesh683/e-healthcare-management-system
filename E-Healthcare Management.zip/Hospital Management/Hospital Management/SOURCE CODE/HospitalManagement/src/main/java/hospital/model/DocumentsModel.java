package hospital.model;

public class DocumentsModel {
		private String documentId;
		private String reportName;
		private String reportDocument;
		private String reportDescription;
		private String charge;
		private String doctorId;
		private String patientId;
		private String laboratoryId;
		private String labTestRequestId;
		private String datee;
		private DoctorModel dm;
		private PatientModel pm;
		private LabTestModel ltm;
		private LabModel lm;
		public DoctorModel getDm() {
			return dm;
		}
		public void setDm(DoctorModel dm) {
			this.dm = dm;
		}
		public PatientModel getPm() {
			return pm;
		}
		public void setPm(PatientModel pm) {
			this.pm = pm;
		}
		public LabTestModel getLtm() {
			return ltm;
		}
		public void setLtm(LabTestModel ltm) {
			this.ltm = ltm;
		}
		public LabModel getLm() {
			return lm;
		}
		public void setLm(LabModel lm) {
			this.lm = lm;
		}
		public String getDocumentId() {
			return documentId;
		}
		public void setDocumentId(String documentId) {
			this.documentId = documentId;
		}
		public String getReportName() {
			return reportName;
		}
		public void setReportName(String reportName) {
			this.reportName = reportName;
		}
		public String getReportDocument() {
			return reportDocument;
		}
		public void setReportDocument(String reportDocument) {
			this.reportDocument = reportDocument;
		}
		public String getReportDescription() {
			return reportDescription;
		}
		public void setReportDescription(String reportDescription) {
			this.reportDescription = reportDescription;
		}
		public String getCharge() {
			return charge;
		}
		public void setCharge(String charge) {
			this.charge = charge;
		}
		public String getDoctorId() {
			return doctorId;
		}
		public void setDoctorId(String doctorId) {
			this.doctorId = doctorId;
		}
		public String getPatientId() {
			return patientId;
		}
		public void setPatientId(String patientId) {
			this.patientId = patientId;
		}
		public String getLaboratoryId() {
			return laboratoryId;
		}
		public void setLaboratoryId(String laboratoryId) {
			this.laboratoryId = laboratoryId;
		}
		public String getLabTestRequestId() {
			return labTestRequestId;
		}
		public void setLabTestRequestId(String labTestRequestId) {
			this.labTestRequestId = labTestRequestId;
		}
		public String getDatee() {
			return datee;
		}
		public void setDatee(String datee) {
			this.datee = datee;
		}
		
}
