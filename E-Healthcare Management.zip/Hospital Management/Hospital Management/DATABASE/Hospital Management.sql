drop database HospitalManagement;
create database HospitalManagement;
use HospitalManagement;

create table doctor(
doctorId int primary key auto_increment,
firstname varchar(255) not null,
lastname varchar(255) not null,
email varchar(255) not null unique,
phone varchar(255) not null unique,
password varchar(255) not null,
designation varchar(255) not null,
specialization varchar(255) not null,
experiance varchar(255) not null,
dateOfJoining varchar(255) not null,
shiftStartTime varchar(255) not null,
shiftEndTime varchar(255) not null,
status varchar(255) not null default'disabled'
);

create table laboratory(
laboratoryId int primary key auto_increment,
labname varchar(255) not null,
operatorname varchar(255) not null,
email varchar(255) not null unique,
phone varchar(255) not null unique,
password varchar(255) not null,
laboratorytype varchar(255) not null,
status varchar(255) not null default'disabled'

);

create table medicalStore(
medicalStoreId int primary key auto_increment,
medicalstorename varchar(255) not null,
operatorname varchar(255) not null,
email varchar(255) not null unique,
phone varchar(255) not null unique,
password varchar(255) not null,
status varchar(255) not null default'disabled'

);

create table frontOffice(
frontOfficeId int primary key auto_increment,
frontofficename varchar(255) not null,
receptionistname varchar(255) not null,
email varchar(255) not null unique,
phone varchar(255) not null unique,
password varchar(255) not null,
status varchar(255) not null default'disabled'
);
create table patient(
patientId int primary key auto_increment,
name varchar(255) not null,
email varchar(255) not null unique,
phone varchar(255) not null unique,
address varchar(255) not null ,
age varchar(255) not null,
gender varchar(255) not null ,
purpose varchar(255) not null ,
password varchar(255) not null 

);
create table reading(
readingId int primary key auto_increment,
readingName varchar(255) not null,
readingValue varchar(255) not null,
status varchar(255) not null,
doctorId int not null,
patientId int not null,
datee DATETIME  default CURRENT_TIMESTAMP,
foreign key (doctorId) references doctor(doctorId),
foreign key (patientId) references patient(patientId)
);
create table healthUpdate(
healthUpdateId int primary key auto_increment,
healthUpdate varchar(255) not null,
doctorId int not null,
patientId int not null,
datee DATETIME  default CURRENT_TIMESTAMP,
foreign key (doctorId) references doctor(doctorId),
foreign key (patientId) references patient(patientId)
);
create table Prescription(
PrescriptionId int primary key auto_increment,
Prescription varchar(255) not null,
doctorId int not null,
patientId int not null,
medicalStoreId  int not null,
status varchar(255) default 'prescribed',
datee DATETIME  default CURRENT_TIMESTAMP,
foreign key (doctorId) references doctor(doctorId),
foreign key (patientId) references patient(patientId),
foreign key (medicalStoreId) references medicalStore(medicalStoreId)
);
create table labTestRequest(
labTestRequestId int primary key auto_increment,
labTestRequest varchar(255) not null,
doctorId int not null,
patientId int not null,
laboratoryId  int not null,
status varchar(255) default 'Requested',
datee DATETIME  default CURRENT_TIMESTAMP,
foreign key (doctorId) references doctor(doctorId),
foreign key (patientId) references patient(patientId),
foreign key (laboratoryId) references laboratory(laboratoryId)
);
create table document(
documentId int primary key auto_increment,
reportName varchar(255) not null,
reportDocument varchar(255) not null,
reportDescription varchar(255) not null,
charge varchar(255) not null,
doctorId int not null,
patientId int not null,
laboratoryId  int not null,
labTestRequestId int not null,
datee DATETIME  default CURRENT_TIMESTAMP,
foreign key (doctorId) references doctor(doctorId),
foreign key (patientId) references patient(patientId),
foreign key (laboratoryId) references laboratory(laboratoryId),
foreign key (labTestRequestId) references labTestRequest(labTestRequestId)
);




